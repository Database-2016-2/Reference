package simpledb.tx.recovery;

import simpledb.log.BasicLogRecord;

class NQCheckpointRecord implements LogRecord{
    private int txnum;
    /**
     * Creates a non-quiescent checkpoint record.
     */
    public NQCheckpointRecord(int txnum) {
        this.txnum = txnum;
    }

    /**
     * Creates a log record by reading no other values
     * from the basic log record.
     * @param rec the basic log record
     */
    public NQCheckpointRecord(BasicLogRecord rec) {
        txnum = rec.nextInt();
    }

    /**
     * Writes a non-quiescent checkpoint record to the log.
     * This log record contains the NQCHECKPOINT operator,
     * and nothing else.
     * @return the LSN of the last log value
     */
    public int writeToLog() {
        Object[] rec = new Object[] {NQCHECKPOINT, txnum};
        return logMgr.append(rec);
    }

    public int op() {
        return NQCHECKPOINT;
    }

    /**
     * Non-quiescent checkpoint records have no associated transaction,
     * and so the method returns a "dummy", negative txid.
     */
    public int txNumber() {
        return -1; // dummy value
    }

    /**
     * Does nothing, because a non-checkpoint record
     * contains no undo information.
     */
    public void undo(int txnum) {}

    public String toString() {
        return "<NQCHECKPOINT " + txnum + ">";
    }
}
