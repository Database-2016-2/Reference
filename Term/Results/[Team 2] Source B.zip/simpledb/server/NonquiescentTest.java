package simpledb.server;

import simpledb.file.Block;
import simpledb.tx.Transaction;

public class NonquiescentTest {
    public static void main(String[] args) throws InterruptedException {
        SimpleDB.init("testdb");
        System.out.println("database server 1st_ready");
        System.out.println();

        TestA t1 = new TestA();        new Thread(t1).start();
        TestB t2 = new TestB();        new Thread(t2).start();
        Thread.sleep(2000);

        System.out.println();
        SimpleDB.init("testdb");
        System.out.println("database server 2nd_ready");
        System.out.println();
        Thread.sleep(2000);

        TestB t3 = new TestB();        new Thread(t3).start();
    }
}

class TestA implements Runnable {
    public void run() {
        Transaction tx = new Transaction();
        Block blk1 = new Block("STUDENT.tbl", 1);
        tx.pin(blk1);

        System.out.println("Tx A: read_1 start");
        int a = tx.getInt(blk1, 1);
        System.out.println(a);

        int b = tx.getInt(blk1, 9);
        System.out.println(b);
        System.out.println("Tx A: read_1 end");

        System.out.println("Tx A: write_1 start");
        tx.setInt(blk1, 1, 100);
        tx.setInt(blk1, 9, 200);
        System.out.println("Tx A: write_1 end");

        System.out.println("Tx A: read_1 start");
        a = tx.getInt(blk1, 1);
        System.out.println(a);

        b = tx.getInt(blk1, 9);
        System.out.println(b);
        System.out.println("Tx A: read_1 end");
        tx.commit();
        }
}

class TestB implements Runnable {
    public void run() {
        try {
            Thread.sleep(1500);
            Transaction tx = new Transaction();
            Block blk1 = new Block("STUDENT.tbl", 1);
            tx.pin(blk1);

            System.out.println("Tx B: read_1 start");
            int a = tx.getInt(blk1, 1);
            System.out.println(a);

            int b = tx.getInt(blk1, 9);
            System.out.println(b);
            System.out.println("Tx B: read_1 end");
            tx.commit();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}