package simpledb.server;

import simpledb.file.Block;
import simpledb.tx.Transaction;

public class NonquiescentTest2 {
    public static void main(String[] args) throws InterruptedException {
        SimpleDB.init("testdb");
        System.out.println("database server 1st_ready");
        System.out.println();

        TestA2 t1 = new TestA2();
        new Thread(t1).start();
        Thread.sleep(2000);

        TestB2 t2 = new TestB2();        new Thread(t2).start();
        TestC2 t3 = new TestC2();        new Thread(t3).start();
        TestD2 t4 = new TestD2();        new Thread(t4).start();
        TestE2 t5 = new TestE2();        new Thread(t5).start();
        Thread.sleep(4000);

        SimpleDB.init("testdb");
        System.out.println("database server 2nd_ready");
        System.out.println();
        Thread.sleep(2000);

        TestA2 t6 = new TestA2();
        new Thread(t6).start();
    }
}

class TestA2 implements Runnable {
    public void run() {
        Transaction tx = new Transaction();
        Block blk1 = new Block("STUDENT.tbl", 1);
        tx.pin(blk1);

        System.out.println("Tx A: read_1 start");
        int a = tx.getInt(blk1, 1);
        int b = tx.getInt(blk1, 9);
        int c = tx.getInt(blk1, 20);
        int d = tx.getInt(blk1, 40);

        System.out.println("offset1: " + a);
        System.out.println("offset9: " + b);
        System.out.println("offset20: " + c);
        System.out.println("offset40: " + d);
        System.out.println("Tx A: read_1 end");
        tx.commit();
    }
}

class TestB2 implements Runnable {
    public void run() {
        Transaction tx = new Transaction();
        Block blk1 = new Block("STUDENT.tbl", 1);
        tx.pin(blk1);

        System.out.println("Tx B2: write start");
        tx.setInt(blk1, 1, 10);
        System.out.println("Tx B2: write end");
        tx.fakecommit();
    }
}
class TestC2 implements Runnable {
    public void run() {
        Transaction tx = new Transaction();
        Block blk1 = new Block("STUDENT.tbl", 1);
        tx.pin(blk1);

        System.out.println("Tx C2: write start");
        tx.setInt(blk1, 9, 20);
        System.out.println("Tx C2: write end");
        tx.commit();
    }
}
class TestD2 implements Runnable {
    public void run() {
        Transaction tx = new Transaction();
        Block blk1 = new Block("STUDENT.tbl", 1);
        tx.pin(blk1);

        System.out.println("Tx D2: write start");
        tx.setInt(blk1, 20, 30);
        System.out.println("Tx D2: write end");
        tx.fakecommit();
    }
}
class TestE2 implements Runnable {
    public void run() {
        Transaction tx = new Transaction();
        Block blk1 = new Block("STUDENT.tbl", 1);
        tx.pin(blk1);

        System.out.println("Tx E2: write start");
        tx.setInt(blk1, 40, 40);
        System.out.println("Tx E2: write end");
        tx.commit();
    }
}
