package simpledb.query;

import simpledb.server.SimpleDB;
import simpledb.tx.Transaction;
import simpledb.metadata.*;
import simpledb.record.*;

import java.util.Arrays;
import java.util.HashMap;

/** The Plan class corresponding to a table.
 * @author Edward Sciore
 */
public class EncryptTablePlan implements Plan {
    private Transaction tx;
    private TableInfo ti;
    private StatInfo si;
    private String key;
    HashMap<String,Integer> encsch=new HashMap<String, Integer>();
    /**
     * Creates a leaf node in the query tree corresponding
     * to the specified table.
     * @param tblname the name of the table
     * @param tx the calling transaction
     */
    public EncryptTablePlan(String tblname,String key, Transaction tx) {
        this.tx = tx;
        ti = SimpleDB.mdMgr().getEncryptTableInfo(tblname, tx);
//        this.key=SimpleDB.mdMgr().getEncryptTableInfo(tblname+"ENC",tx).getKey();
        this.key=key;
        si = SimpleDB.mdMgr().getStatInfo(tblname, ti, tx);
        Scan s1=new TableScan(SimpleDB.mdMgr().getTableInfo(tblname+"ENC",tx),tx);
        Scan s2=new ProjectScan(s1, Arrays.asList("name","type"));
        while(s2.next()){
            this.encsch.put(s2.getString("name"),s2.getInt("type"));
        }
    }

    /**
     * Creates a table scan for this query.
     * @see simpledb.query.Plan#open()
     */
    public Scan open() {
        return new EncryptTableScan(ti,this.key,this.encsch, tx);
    }

    /**
     * Estimates the number of block accesses for the table,
     * which is obtainable from the statistics manager.
     * @see simpledb.query.Plan#blocksAccessed()
     */
    public int blocksAccessed() {
        return si.blocksAccessed();
    }

    /**
     * Estimates the number of records in the table,
     * which is obtainable from the statistics manager.
     * @see simpledb.query.Plan#recordsOutput()
     */
    public int recordsOutput() {
        return si.recordsOutput();
    }

    /**
     * Estimates the number of distinct field values in the table,
     * which is obtainable from the statistics manager.
     * @see simpledb.query.Plan#distinctValues(java.lang.String)
     */
    public int distinctValues(String fldname) {
        return si.distinctValues(fldname);
    }

    /**
     * Determines the schema of the table,
     * which is obtainable from the catalog manager.
     * @see simpledb.query.Plan#schema()
     */
    public Schema schema() {
        return ti.schema();
    }
}
