package simpledb.parse;

import simpledb.query.Constant;
import simpledb.planner.BasicUpdatePlanner;
import simpledb.record.Schema;

import java.util.*;
/**
 * Data for the SQL <i>create table</i> statement.
 * @author Edward Sciore
 */
public class CreateEncryptTableData {
    private String tblname;
    private Schema sch;
    private String encryptTblname;
    private String key;
    private Schema encryptSch = new Schema();
    /**
     * Saves the table name and schema.
     */
    public CreateEncryptTableData(String tblname,String key, Schema sch) {

        this.tblname = (tblname);
        this.sch = sch;
        this.key=key;
        this.encryptTblname = (tblname+"ENC");
        this.encryptSch.addStringField("name", 20);
        this.encryptSch.addIntField("type");
        this.encryptSch.addIntField("length");



//        Iterator<String> iter=sch.fields().iterator();
//        while(iter.hasNext()){
//            String fldname=iter.next();
//            System.out.println(this.tblname + "|" + Arrays.asList("name", "type", "length") + "|" + Arrays.<Constant>asList(new StringConstant(fldname), new IntConstant(sch.type(fldname)), new IntConstant(sch.length(fldname))));
////            new InsertData(this.tblname,Arrays.asList("name", "type", "length"), Arrays.<Constant>asList(new StringConstant(fldname),new IntConstant(sch.type(fldname)),new IntConstant(sch.length(fldname)))));
//
//        }

        
    }

    /**
     * Returns the name of the new table.
     * @return the name of the new table
     */
    public String tableName() {
        return tblname;
    }
    public String getKey(){return key;}
    public void setKey(String key){this.key=key;}
    /**
     * Returns the schema of the new table.
     * @return the schema of the new table
     */
    public Schema newSchema() {
        return sch;
    }

    public String encryptTableName() { return encryptTblname; }


    public Schema encryptNewSchema() { return encryptSch; }

}
