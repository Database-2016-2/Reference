package simpledb.metadata;

import simpledb.parse.InsertData;
import simpledb.planner.UpdatePlanner;
import simpledb.query.Constant;
import simpledb.query.IntConstant;
import simpledb.query.StringConstant;
import simpledb.tx.Transaction;
import simpledb.record.*;
import simpledb.planner.BasicUpdatePlanner;
import java.util.Arrays;
import java.util.Iterator;
import java.util.Map;

public class MetadataMgr {
   private static TableMgr  tblmgr;
   private static ViewMgr   viewmgr;
   private static StatMgr   statmgr;
   private static IndexMgr  idxmgr;
   
   public MetadataMgr(boolean isnew, Transaction tx) {
      tblmgr  = new TableMgr(isnew, tx);
      viewmgr = new ViewMgr(isnew, tblmgr, tx);
      statmgr = new StatMgr(tblmgr, tx);
      idxmgr  = new IndexMgr(isnew, tblmgr, tx);
   }
   public void createEncryptTable(String tblname, String key,Schema sch, Transaction tx) {
      Schema encryptSch = new Schema();
      encryptSch.addStringField("name", 20);
      encryptSch.addIntField("type");
      encryptSch.addIntField("length");
      tblmgr.createEncryptTable(tblname,key, encryptSch, tx);
      Iterator<String> iter = sch.fields().iterator();
      while (iter.hasNext()) {
         String fldname = iter.next();
         new BasicUpdatePlanner().executeInsert(new InsertData(tblname,Arrays.asList("name", "type", "length"), Arrays.<Constant>asList(new StringConstant(fldname),new IntConstant(sch.type(fldname)),new IntConstant(sch.length(fldname)))),tx);
        }
   }
   public void createTable(String tblname, Schema sch, Transaction tx) {
      tblmgr.createTable(tblname, sch, tx);
   }
   
   public TableInfo getTableInfo(String tblname, Transaction tx) {
      return tblmgr.getTableInfo(tblname, tx);
   }

   public TableInfo getEncryptTableInfo(String tblname, Transaction tx) {
      return tblmgr.getEncryptTableInfo(tblname, tx);
   }

   public void createView(String viewname, String viewdef, Transaction tx) {
      viewmgr.createView(viewname, viewdef, tx);
   }
   
   public String getViewDef(String viewname, Transaction tx) {
      return viewmgr.getViewDef(viewname, tx);
   }
   
   public void createIndex(String idxname, String tblname, String fldname, Transaction tx) {
      idxmgr.createIndex(idxname, tblname, fldname, tx);
   }
   
   public Map<String,IndexInfo> getIndexInfo(String tblname, Transaction tx) {
      return idxmgr.getIndexInfo(tblname, tx);
   }
   
   public StatInfo getStatInfo(String tblname, TableInfo ti, Transaction tx) {
      return statmgr.getStatInfo(tblname, ti, tx);
   }
}
