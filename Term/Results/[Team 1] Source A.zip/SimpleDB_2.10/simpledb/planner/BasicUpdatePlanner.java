package simpledb.planner;

import java.util.Arrays;
import java.util.Iterator;

import simpledb.record.Schema;
import simpledb.record.TableInfo;
import simpledb.server.SimpleDB;
import simpledb.tx.Transaction;
import simpledb.parse.*;
import simpledb.query.*;
import simpledb.encrypt.*;
import sun.java2d.pipe.SpanShapeRenderer;

/**
 * The basic planner for SQL update statements.
 * @author sciore
 */
public class BasicUpdatePlanner implements UpdatePlanner {

   public int executeDelete(DeleteData data, Transaction tx) {
      Plan p = new TablePlan(data.tableName(), tx);;

      Scan s1=new TableScan(SimpleDB.mdMgr().getTableInfo("ENCTABLELIST",tx),tx);
      Scan s2=new ProjectScan(s1,Arrays.asList("tablename"));
      while(s2.next()) {
         if (s2.getString("tablename").compareTo(data.tableName()) == 0) {
            p=new EncryptTablePlan(data.tableName(),data.getKey(), tx);
            break;
         }
      }
      p = new SelectPlan(p, data.pred());
      UpdateScan us = (UpdateScan) p.open();
      int count = 0;
      while(us.next()) {
         us.delete();
         count++;
      }
      us.close();
      return count;
   }

   public int executeModify(ModifyData data, Transaction tx) {
      Plan p = new TablePlan(data.tableName(), tx);
      StringConstant cipherText=null;
      Scan s1=new TableScan(SimpleDB.mdMgr().getTableInfo("ENCTABLELIST",tx),tx);
      Scan s2=new ProjectScan(s1,Arrays.asList("tablename"));
      while(s2.next()) {
         if (s2.getString("tablename").compareTo(data.tableName()) == 0) {
            p=new EncryptTablePlan(data.tableName(),data.getKey(), tx);
            break;
         }
      }

      p = new SelectPlan(p, data.pred());
      UpdateScan us = (UpdateScan) p.open();
      int count = 0;
      while(us.next()) {

         if (encryptFieldCheck(data.tableName(),data.targetField(), tx) == 0) {

            Constant val = data.newValue().evaluate(us);
            us.setVal(data.targetField(), val);
         }else if (encryptFieldCheck(data.tableName(),data.targetField(), tx) == 1) {

            Constant val = data.newValue().evaluate(us);
            try {
               cipherText = new StringConstant(new AesEncrypt().Encrypt(val.toString(), data.getKey()));
            }catch (Exception e) {
               e.printStackTrace();
            }
            us.setVal(data.targetField(), cipherText);
         }else if (encryptFieldCheck(data.tableName(),data.targetField(), tx)==2) {

            Constant val = data.newValue().evaluate(us);
            try {
               cipherText = new StringConstant(new AesEncrypt().Encrypt(Integer.toBinaryString((Integer) val.asJavaVal()), data.getKey()));
            } catch (Exception e) {
               e.printStackTrace();
            }
            us.setVal(data.targetField(), cipherText);
         }
//         Constant val = data.newValue().evaluate(us);
//         us.setVal(data.targetField(), val);
         count++;
      }
      us.close();
      return count;
   }
   public int executeInsert(InsertData data, Transaction tx) {
      Plan p = new TablePlan(data.tableName(), tx);
      UpdateScan us = (UpdateScan) p.open();
      StringConstant cipherText=null;
      us.insert();
      Iterator<Constant> iter = data.vals().iterator();
      Scan s1=new TableScan(SimpleDB.mdMgr().getTableInfo("ENCTABLELIST",tx),tx);
      Scan s2=new ProjectScan(s1,Arrays.asList("tablename"));

      for (String fldname : data.fields()) {
         if (encryptFieldCheck(data.tableName(),fldname, tx) == 0) {
            Constant val = iter.next();
            us.setVal(fldname, val);
         }else if (encryptFieldCheck(data.tableName(),fldname, tx) == 1) {
            Constant val = iter.next();
            try {
               cipherText = new StringConstant(new AesEncrypt().Encrypt(val.toString(), data.getKey()));
            }catch (Exception e) {
               e.printStackTrace();
            }
            us.setVal(fldname, cipherText);
         }else if (encryptFieldCheck(data.tableName(),fldname, tx)==2) {
            Constant val = iter.next();
            try {
               cipherText = new StringConstant(new AesEncrypt().Encrypt(Integer.toBinaryString((Integer) val.asJavaVal()), data.getKey()));
            } catch (Exception e) {
               e.printStackTrace();
            }
            us.setVal(fldname, cipherText);
         }
      }
      us.close();
      return 1;
   }
   public int encryptFieldCheck(String tblname,String fldname, Transaction tx){
      String enctablename=tblname;
      Scan s1=new TableScan(SimpleDB.mdMgr().getTableInfo("ENCTABLELIST",tx),tx);
      Scan s2=new ProjectScan(s1,Arrays.asList("tablename"));
      while(s2.next()){
         if(s2.getString("tablename").compareTo(tblname)==0) {
            Scan s3=new TableScan(SimpleDB.mdMgr().getTableInfo(s2.getString("tablename")+"ENC",tx),tx);
            Scan s4=new ProjectScan(s3,Arrays.asList("name","type"));
            while(s4.next()){
               if(s4.getString("name").compareTo(fldname)==0) {
                  if(s4.getInt("type")==12)
                     return 1;
                  else if(s4.getInt("type")==4)
                     return 2;
               }
            }

         }
      }
      return 0;
   }
   public int executeEncryptCreateTable(CreateEncryptTableData encryptData, Transaction tx) {
      Schema encryptSch = new Schema(),encryptedTableListSch = new Schema();

      encryptedTableListSch.addStringField("tablename", 20);
      SimpleDB.mdMgr().createTable("ENCTABLELIST", encryptedTableListSch, tx);
      executeInsert(new InsertData("ENCTABLELIST", Arrays.asList("tablename"), Arrays.<Constant>asList(new StringConstant(encryptData.tableName()))), tx);

      SimpleDB.mdMgr().createEncryptTable(encryptData.encryptTableName(),encryptData.getKey(), encryptData.newSchema(), tx);
      Iterator<String> iter = encryptData.newSchema().fields().iterator();
      while(iter.hasNext()){
         String fldname = iter.next();
         if(encryptData.newSchema().type(fldname)==12)
            encryptSch.addStringField(fldname, ((encryptData.newSchema().length(fldname)) / 16 + 1) * 16);
         else
            encryptSch.addStringField(fldname, 16);

      }
      SimpleDB.mdMgr().createTable(encryptData.tableName(), encryptSch, tx);

      return 0;
   }
   public int executeCreateTable(CreateTableData data, Transaction tx) {
      SimpleDB.mdMgr().createTable(data.tableName(), data.newSchema(), tx);
      return 0;
   }

   public int executeCreateView(CreateViewData data, Transaction tx) {
      SimpleDB.mdMgr().createView(data.viewName(), data.viewDef(), tx);
      return 0;
   }
   public int executeCreateIndex(CreateIndexData data, Transaction tx) {
      SimpleDB.mdMgr().createIndex(data.indexName(), data.tableName(), data.fieldName(), tx);
      return 0;
   }
}
