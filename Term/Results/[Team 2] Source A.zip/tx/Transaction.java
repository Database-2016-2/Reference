package simpledb.tx;

import simpledb.server.SimpleDB;
import simpledb.file.Block;
import simpledb.buffer.*;
import simpledb.tx.recovery.RecoveryMgr;
import simpledb.tx.concurrency.ConcurrencyMgr;

/**
 * Provides transaction management for clients,
 * ensuring that all transactions are serializable, recoverable,
 * and in general satisfy the ACID properties.
 *
 * @author Edward Sciore
 */
public class Transaction { //bufferMgr과 비슷.
    private static int nextTxNum = 0;
    private static final int END_OF_FILE = -1;
    private RecoveryMgr recoveryMgr;
    private ConcurrencyMgr concurMgr;
    private int txnum;
    private BufferList myBuffers = new BufferList();

    /**
     * Creates a new transaction and its associated
     * recovery and concurrency managers.
     * This constructor depends on the file, log, and buffer
     * managers that it gets from the class
     * {@link simpledb.server.SimpleDB}.
     * Those objects are created during system initialization.
     * Thus this constructor cannot be called until either
     * {@link simpledb.server.SimpleDB#init(String)} or
     * {@link simpledb.server.SimpleDB#initFileLogAndBufferMgr(String)} or
     * is called first.
     */
    public Transaction() {
        txnum = nextTxNumber();
        recoveryMgr = new RecoveryMgr(txnum);
        concurMgr = new ConcurrencyMgr();
    }

    public int getTxnum() { //여기서 현재 transaction의 번호를 가져옴
        return txnum;
    }

    /**
     * Commits the current transaction.
     * Flushes all modified buffers (and their log records),
     * writes and flushes a commit record to the log,
     * releases all locks, and unpins any pinned buffers.
     */
    public void commit() {
        recoveryMgr.commit();
        concurMgr.release(); //모든 lock을 놓아줌
        myBuffers.unpinAll(); //남아있는 buffer unpin!
        System.out.println("transaction " + txnum + " committed");
    }

    /*public void commit() { //모든 log를 flush하는 것을 의미한다.
        recoveryMgr.commit(); //recovery commit 호출(commit log남김)
        //recover();
        concurMgr.release(); //모든 lock을 놓아줌
        myBuffers.unpinAll(); //남아있는 buffer unpin!
        System.out.println("transaction " + txnum + " committed");
    }*/

    /**
     * Rolls back the current transaction.
     * Undoes any modified values,
     * flushes those buffers,
     * writes and flushes a rollback record to the log,
     * releases all locks, and unpins any pinned buffers.
     */
    public void rollback() { //되돌리기 위한 method
        recoveryMgr.rollback(); //rollback log를 남김
        concurMgr.release(); //lock 놓아줌
        myBuffers.unpinAll(); //현재 모든 buffer를 놓아줌
        System.out.println("transaction " + txnum + " rolled back");
    }

    /**
     * Flushes all modified buffers.
     * Then goes through the log, rolling back all
     * uncommitted transactions.  Finally,
     * writes a quiescent checkpoint record to the log.
     * This method is called only during system startup,
     * before user transactions begin.
     */
    public void recover() { //복구를 위한 재수행
        SimpleDB.bufferMgr().flushAll(txnum); //현재 모든 버퍼의 내용을 disk로 flush
        recoveryMgr.recover(); //recovery 수행.
        //지금 simpledb의 recover는 flush되는 도중 오류가 나지 않는다는 전제가 있으므로, recovery가 commit때 까지 되돌리는 것을 의미한다.
        //System.out.println("recover is the end!");
    }

    /**
     * Pins the specified block.
     * The transaction manages the buffer for the client.
     *
     * @param blk a reference to the disk block
     */
    public void pin(Block blk) {
        myBuffers.pin(blk);
    } //버퍼매니저와 다르게 버퍼의 존재를 숨긴다.

    /**
     * Unpins the specified block.
     * The transaction looks up the buffer pinned to this block,
     * and unpins it.
     *
     * @param blk a reference to the disk block
     */
    public void unpin(Block blk) {
        myBuffers.unpin(blk);
    }

    /**
     * Returns the integer value stored at the
     * specified offset of the specified block.
     * The method first obtains an SLock on the block,
     * then it calls the buffer to retrieve the value.
     *
     * @param blk    a reference to a disk block
     * @param offset the byte offset within the block
     * @return the integer stored at that offset
     */
   /*public int getInt(Block blk, int offset) { //timeout을 위한 getint
      concurMgr.sLock(blk);
      Buffer buff = myBuffers.getBuffer(blk);
      return buff.getInt(offset);
   }*/
    public int getInt(Block blk, int offset) {
        int result;
        result = concurMgr.sLock(blk, txnum); //read하는 것이므로 slock을 얻어온다.

        if (result == 0) {
            System.out.println("txnum:" + getTxnum() + ", rollback");
            rollback();
        }

        Buffer buff = myBuffers.getBuffer(blk);
        return buff.getInt(offset);
    }

    /**
     * Returns the string value stored at the
     * specified offset of the specified block.
     * The method first obtains an SLock on the block,
     * then it calls the buffer to retrieve the value.
     *
     * @param blk    a reference to a disk block
     * @param offset the byte offset within the block
     * @return the string stored at that offset
     */
   /*public String getString(Block blk, int offset) { //timeout을 위한 getstring
      concurMgr.sLock(blk);
      Buffer buff = myBuffers.getBuffer(blk);
      return buff.getString(offset);
   }*/
    public String getString(Block blk, int offset) {
        int result;
        result = concurMgr.sLock(blk, txnum);

        if (result == 0) {
            System.out.println("txnum:" + getTxnum() + ", rollback");
            rollback();
        }

        Buffer buff = myBuffers.getBuffer(blk);
        return buff.getString(offset);
    }

    /**
     * Stores an integer at the specified offset
     * of the specified block.
     * The method first obtains an XLock on the block.
     * It then reads the current value at that offset,
     * puts it into an update log record, and
     * writes that record to the log.
     * Finally, it calls the buffer to store the value,
     * passing in the LSN of the log record and the transaction's id.
     *
     * @param blk    a reference to the disk block
     * @param offset a byte offset within that block
     * @param val    the value to be stored
     */
    //set method는 lock과 log가 필요
   /*public void setInt(Block blk, int offset, int val) { //timeout을 위한 setint
      concurMgr.xLock(blk);
      Buffer buff = myBuffers.getBuffer(blk);
      int lsn = recoveryMgr.setInt(buff, offset, val);
      buff.setInt(offset, val, txnum, lsn);
   }*/
    public void setInt(Block blk, int offset, int val) {
        int result;
        result = concurMgr.xLock(blk, getTxnum()); //write하는 것이므로 xlock을 얻어온다.

        if (result != 0) { //xlock을 획득한 경우
            Buffer buff = myBuffers.getBuffer(blk);
            int lsn = recoveryMgr.setInt(buff, offset, val);
            buff.setInt(offset, val, txnum, lsn);
        } else { //0을 return 받아 rollback을 해야하는 경우
            System.out.println("txnum:" + getTxnum() + ", rollback");
            rollback();
        }
    }

    /**
     * Stores a string at the specified offset
     * of the specified block.
     * The method first obtains an XLock on the block.
     * It then reads the current value at that offset,
     * puts it into an update log record, and
     * writes that record to the log.
     * Finally, it calls the buffer to store the value,
     * passing in the LSN of the log record and the transaction's id.
     *
     * @param blk    a reference to the disk block
     * @param offset a byte offset within that block
     * @param val    the value to be stored
     */
   /*public void setString(Block blk, int offset, String val) { //timeout을 위한 setstring
      concurMgr.xLock(blk);
      Buffer buff = myBuffers.getBuffer(blk);
      int lsn = recoveryMgr.setString(buff, offset, val);
      buff.setString(offset, val, txnum, lsn);
   }*/
    public void setString(Block blk, int offset, String val) {
        int result;
        result = concurMgr.xLock(blk, getTxnum());

        if (result != 0) { //xlock을 획득한 경우
            Buffer buff = myBuffers.getBuffer(blk);
            int lsn = recoveryMgr.setString(buff, offset, val);
            buff.setString(offset, val, txnum, lsn);
        } else {
            System.out.println("txnum:" + getTxnum() + ", rollback");
            rollback();
        }
    }

    /**
     * Returns the number of blocks in the specified file.
     * This method first obtains an SLock on the
     * "end of the file", before asking the file manager
     * to return the file size.
     *
     * @param filename the name of the file
     * @return the number of blocks in the file
     */
   /*public int size(String filename) { //timeout을 위한 size
      Block dummyblk = new Block(filename, END_OF_FILE);
      concurMgr.sLock(dummyblk);
      return SimpleDB.fileMgr().size(filename);
   }*/
    public int size(String filename) { //slock (file의 크기를 읽는 것이므로)
        Block dummyblk = new Block(filename, END_OF_FILE);
        int result;
        result = concurMgr.sLock(dummyblk, getTxnum()); //가장 마지막 블록에 lock을 건다.
        if(result ==0)
            rollback();

        return SimpleDB.fileMgr().size(filename);
    }

    /**
     * Appends a new block to the end of the specified file
     * and returns a reference to it.
     * This method first obtains an XLock on the
     * "end of the file", before performing the append.
     *
     * @param filename the name of the file
     * @param fmtr     the formatter used to initialize the new page
     * @return a reference to the newly-created disk block
     */
   /*public Block append(String filename, PageFormatter fmtr) {
      Block dummyblk = new Block(filename, END_OF_FILE);
      concurMgr.xLock(dummyblk);
      Block blk = myBuffers.pinNew(filename, fmtr);
      unpin(blk);
      return blk;
   }*/
    public Block append(String filename, PageFormatter fmtr) { //xlock
        Block dummyblk = new Block(filename, END_OF_FILE);
        int result;
        result = concurMgr.xLock(dummyblk, getTxnum()); //가장 마지막 블록에 xlock을 건다.

        if(result==0)
            rollback();

        Block blk = myBuffers.pinNew(filename, fmtr);
        unpin(blk);
        return blk;
    }

    private static synchronized int nextTxNumber() {
        nextTxNum++;
        System.out.println("new transaction: " + nextTxNum);
        return nextTxNum;
    }
}
