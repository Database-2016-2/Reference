package simpledb.tx.concurrency;

import simpledb.file.Block;
import java.util.*;

/**
 * The lock table, which provides methods to lock and unlock blocks.
 * If a transaction requests a lock that causes a conflict with an
 * existing lock, then that transaction is placed on a wait list.
 * There is only one wait list for all blocks.
 * When the last lock on a block is unlocked, then all transactions
 * are removed from the wait list and rescheduled.
 * If one of those transactions discovers that the lock it is waiting for
 * is still locked, it will place itself back on the wait list.
 *
 * @author Edward Sciore
 */
class LockTable { //block 단위의 lock
    private static final long MAX_TIME = 10000; // 10 seconds, dead lock일 때 time out시간

    private Map<Block, Integer> locks = new HashMap<Block, Integer>(); //block과 lock을 mapping
    //-1: xlock, 양수: slock
    private Map<Block, Integer> txnums = new HashMap<Block, Integer>();
    //현재 txnum 설정

    /**
     * Grants an SLock on the specified block.
     * If an XLock exists when the method is called,
     * then the calling thread will be placed on a wait list
     * until the lock is released.
     * If the thread remains on the wait list for a certain
     * amount of time (currently 10 seconds),
     * then an exception is thrown.
     *
     * @param blk a reference to the disk block
     */
    /*public synchronized void sLock(Block blk) { //timeout을 위한 slock method
        try {
            long timestamp = System.currentTimeMillis();

            while (hasXlock(blk) && !waitingTooLong(timestamp))
                wait(MAX_TIME);
            if (hasXlock(blk))
                throw new LockAbortException();

            int val = getLockVal(blk);
            locks.put(blk, val + 1);
        } catch (InterruptedException e) {
            throw new LockAbortException();
        }
    }*/

    public synchronized int sLock(Block blk, int txnum) { //다른 블록이 있어도 포함 가능, read 전용, 원래의 return type은 void.
        try {
            long timestamp = System.currentTimeMillis();

            while (hasXlock(blk) && !waitingTooLong(timestamp)) //xlock의 여부 확인 (해당 블록에 있는지 없는지)
                wait(MAX_TIME); //max time 정도 까지만 wait
            if (hasXlock(blk)) {
                //지금 현재 block이 xlock을 포함하고 있을 때 lock을 확인하는 transaction이 먼저인지 나중인지 확인한다.
                //System.out.println("This block has XLOCK. Current txnum of SLOCK of this block: " + getlockOrder(blk) + ", input txnum: " + txnum);

                //만약 현재 block을 차지한 transaction이 lock을 요청하는 transaction보다 먼저 생긴 transaction 이라면!
                if (getlockOrder(blk) < txnum) {
                    return 0; //해당 txnum에 대한 transaction을 rollback 하기 위한 return 값.
                }
            }

            //만약 현재 block을 차지한 transaction이 lock을 요청하는 transaction보다 나중에 생긴 transaction 이라면!
            if(getlockOrder(blk) > txnum){
                while (hasXlock(blk)) {
                    wait(1000); //계속 대기함. 현재 block의 lock이 다 풀릴 때 까지.
                }
            }

            //대기 이후, 혹은 같은 transaction이 다시 요청하는 거라면!
            int val = getLockVal(blk);  // will not be negative
            locks.put(blk, val + 1);
            //System.out.println("slock current txnum: " + getlockOrder(blk) + ", input txnum: " + txnum);
            txnums.put(blk, txnum);
            //System.out.println("slock setting txnum: " + getlockOrder(blk));
            //System.out.println("Curren lock number: " + getLockVal(blk));
            return getLockVal(blk); //현재 lock을 return
        } catch (InterruptedException e) {
            throw new LockAbortException();
        }
    }


    /**
     * Grants an XLock on the specified block.
     * If a lock of any type exists when the method is called,
     * then the calling thread will be placed on a wait list
     * until the locks are released.
     * If the thread remains on the wait list for a certain
     * amount of time (currently 10 seconds),
     * then an exception is thrown.
     *
     * @param blk a reference to the disk block
     */
    /*synchronized void xLock(Block blk) {
        try {
            long timestamp = System.currentTimeMillis();
            while (hasOtherSLocks(blk) && !waitingTooLong(timestamp))
                wait(MAX_TIME);
            if (hasOtherSLocks(blk))
                throw new LockAbortException();

            locks.put(blk, -1);

        } catch (InterruptedException e) {
            throw new LockAbortException();
        }
    }*/

    synchronized int xLock(Block blk, int txnum) { //원래는 void, synchronized int xLock(Block blk, int txnum)
        try {
            long timestamp = System.currentTimeMillis();
            if(getlockOrder(blk)!=txnum) {
                while ((hasXlock(blk) || hasOtherSLocks(blk)) && !waitingTooLong(timestamp)) //slock이 하나라도 있는지 확인하고, xlock도 확인
                    wait(MAX_TIME);
                if (hasOtherSLocks(blk) || hasXlock(blk)) { //만약에 xlock 또는 slock이 존재한다면
                    //System.out.println("This block has XLOCK or SLOCK. Current txnum of XLOCK of this block: " + getlockOrder(blk) + ", input txnum: " + txnum);

                    if (getlockOrder(blk) < txnum) {
                        return 0;
                    }
                }

                if (getlockOrder(blk) > txnum) {
                    while (hasOtherSLocks(blk) || hasXlock(blk))
                        wait(1000);
                }
            }
            //System.out.println("xlock current txnum: " + getlockOrder(blk) + ", input txnum: " + txnum);
            txnums.put(blk, txnum);
            //System.out.println("xlock setting txnum: " + getlockOrder(blk));
            locks.put(blk, -1);
            //System.out.println("Curren lock number: " + getLockVal(blk));
            return getLockVal(blk);
        } catch (InterruptedException e) {
            throw new LockAbortException();
        }
    }

    /**
     * Releases a lock on the specified block.
     * If this lock is the last lock on that block,
     * then the waiting transactions are notified.
     *
     * @param blk a reference to the disk block
     */
    synchronized void unlock(Block blk) { //locking 해제
        int val = getLockVal(blk);
        if (val > 1)
            locks.put(blk, val - 1);
        else {
            locks.remove(blk);
            notifyAll(); //모든 쓰레드 제거
        }
    }

    private boolean hasXlock(Block blk) {
        return getLockVal(blk) < 0;
    }

    private int getlockOrder(Block blk) {
        Integer ival = txnums.get(blk);
        return (ival == null) ? 0 : ival.intValue();
    }

    private boolean hasOtherSLocks(Block blk) {
        return getLockVal(blk) > 0;
    } //기존의 timeout때는 1이었음 (0으로 바꿈)

    private boolean waitingTooLong(long starttime) {
        return System.currentTimeMillis() - starttime > MAX_TIME;
    }

    private int getLockVal(Block blk) { //해당 lock이 무엇인지
        Integer ival = locks.get(blk);
        return (ival == null) ? 0 : ival.intValue();
    }
}
