package simpledb.tx.concurrency;

import simpledb.file.Block;

import java.util.*;

/**
 * The concurrency manager for the transaction.
 * Each transaction has its own concurrency manager.
 * The concurrency manager keeps track of which locks the
 * transaction currently has, and interacts with the
 * global lock table as needed.
 *
 * @author Edward Sciore
 */
public class ConcurrencyMgr { //block-level의 locking

    /**
     * The global lock table.  This variable is static because all transactions
     * share the same table.
     */
    private static LockTable locktbl = new LockTable();
    private Map<Block, String> locks = new HashMap<Block, String>(); //String은 S or X

    /**
     * Obtains an SLock on the block, if necessary.
     * The method will ask the lock table for an SLock
     * if the transaction currently has no locks on that block.
     *
     * @param blk a reference to the disk block
     */
   /*public void sLock(Block blk) {
      if (locks.get(blk) == null) {
         locktbl.sLock(blk);
         locks.put(blk, "S");
      }
   }*/
    public int sLock(Block blk, int txnum) {
        int result;
        if (locks.get(blk) == null) { //null이 아니라면 lock table을 갈 필요가 없다. 이미 check 되어 있을 것이기 때문에!
            result = locktbl.sLock(blk, txnum); //lock table에서 slock 체크. 만약에 xlock이 있다면 exception 발생.
            if (result == 0) { //만약에 0이라면 rollback을 해야 함.
                return 0;
            }
            locks.put(blk, "S");
            return result;
        }
        //S가 존재하거나, 혹은 X가 존재하면 한 transaction이 같은 block을 건드린 것이다.
        return 1;
    }

    /**
     * Obtains an XLock on the block, if necessary.
     * If the transaction does not have an XLock on that block,
     * then the method first gets an SLock on that block
     * (if necessary), and then upgrades it to an XLock.
     *
     * @param blk a refrence to the disk block
     */
   /*public void xLock(Block blk) { //timeout을 위한 xlock
      if (!hasXLock(blk)) {
         sLock(blk);
         locktbl.xLock(blk);
      }
   }*/
    public int xLock(Block blk, int txnum) { //원래는 void
        if (!hasXLock(blk)) { //xlock이 없어야 해! 즉 SBlock이거나, null일 경우!
            int result = locktbl.xLock(blk, txnum); //xlock 얻은 후에!

            if (result == 0)
                return 0;

            locks.put(blk, "X");
            return result;
        }
        //XBlock이 존재할 경우
        return 1;
    }

    /**
     * Releases all locks by asking the lock table to
     * unlock each one.
     */
    public void release() { //lock을 다 놓아줌
        for (Block blk : locks.keySet())
            locktbl.unlock(blk);
        locks.clear();
    }

    private boolean hasXLock(Block blk) {
        String locktype = locks.get(blk);
        return locktype != null && locktype.equals("X");
    }
}
