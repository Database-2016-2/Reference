package simpledb.query;

import simpledb.record.Schema;
import simpledb.server.SimpleDB;
import simpledb.tx.Transaction;
import simpledb.record.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * The Plan class corresponding to the <i>project</i> relational algebra
 * operator.
 * 
 * @author Edward Sciore
 */
public class ProjectPlan implements Plan {
	private Plan p;
	private Schema schema = new Schema();
	private Collection<TableInfo> ti = new ArrayList<TableInfo>();

	/**
	 * Creates a new project node in the query tree, having the specified
	 * subquery and field list.
	 * 
	 * @param p
	 *            the subquery
	 * @param fieldlist
	 *            the list of fields
	 */
	public ProjectPlan(Plan p, Collection<String> tables,
			Collection<String> fields, Transaction tx) {
															
		this.p = p;

		for (String tblname : tables) {
			ti.add(SimpleDB.mdMgr().getTableInfo(tblname, tx));
		}

		for (String fldname : fields) {
			if (fldname.equals("*")) {
				for (TableInfo all : ti) {
					Iterator<String> iter = all.schema().fields().iterator();
					while (iter.hasNext()) {
						String keys = (String) iter.next();
						schema.add(keys, p.schema());
					}
				}
			}
			else
				schema.add(fldname, p.schema());
		}
	}

	/**
	 * Creates a project scan for this query.
	 * 
	 * @see simpledb.query.Plan#open()
	 */
	public Scan open() {
		Scan s = p.open();
		return new ProjectScan(s, schema.fields());
	}

	/**
	 * Estimates the number of block accesses in the projection, which is the
	 * same as in the underlying query.
	 * 
	 * @see simpledb.query.Plan#blocksAccessed()
	 */
	public int blocksAccessed() {
		return p.blocksAccessed();
	}

	/**
	 * Estimates the number of output records in the projection, which is the
	 * same as in the underlying query.
	 * 
	 * @see simpledb.query.Plan#recordsOutput()
	 */
	public int recordsOutput() {
		return p.recordsOutput();
	}

	/**
	 * Estimates the number of distinct field values in the projection, which is
	 * the same as in the underlying query.
	 * 
	 * @see simpledb.query.Plan#distinctValues(java.lang.String)
	 */
	public int distinctValues(String fldname) {
		return p.distinctValues(fldname);
	}

	/**
	 * Returns the schema of the projection, which is taken from the field list.
	 * 
	 * @see simpledb.query.Plan#schema()
	 */
	public Schema schema() {
		return schema;
	}
}
