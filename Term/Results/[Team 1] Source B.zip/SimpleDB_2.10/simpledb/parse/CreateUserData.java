package simpledb.parse;

/**
 * Created by wan on 6/13/15.
 */
public class CreateUserData {
    private String username, password;

    /**
     * Saves the view name and its definition.
     */
    public CreateUserData(String username, String password) {
        this.username = username;
        this.password = password;
    }

    /**
     * Returns the name of the new view.
     * @return the name of the new view
     */
    public String userName() {
        return username;
    }

    /**
     * Returns the definition of the new view.
     * @return the definition of the new view
     */
    public String userPass() {
        return password;
    }
}
