package simpledb.parse;

import java.util.Collection;

/**
 * Created by WanH on 15-06-13.
 */
public class GrantData {
    private Collection<String> privs;
    private String username;
    private String tblname;

    public GrantData(String username, String tblname, Collection<String> privs) {
        this.username = username;
        this.tblname = tblname;
        this.privs = privs;
    }

    public Collection<String> getPrivs() {
        return privs;
    }

    public String getUsername() {
        return username;
    }

    public String getTblname() {
        return tblname;
    }
}
