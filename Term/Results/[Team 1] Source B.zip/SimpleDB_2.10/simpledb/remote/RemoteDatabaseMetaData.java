package simpledb.remote;

import java.rmi.*;

/**
 * Created by wan on 15. 5. 7.
 */
public interface RemoteDatabaseMetaData extends Remote {
    public int getDatabaseMajorVersion() throws RemoteException;
    public int getDatabaseMinorVersion() throws RemoteException;
    public RemoteResultSet getTables() throws RemoteException;
}
