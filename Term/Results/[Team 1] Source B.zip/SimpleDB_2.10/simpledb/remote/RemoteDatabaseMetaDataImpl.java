package simpledb.remote;

import simpledb.query.Plan;
import simpledb.server.SimpleDB;
import simpledb.tx.Transaction;

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;

/**
 * Created by wan on 15. 5. 7.
 */
public class RemoteDatabaseMetaDataImpl extends UnicastRemoteObject implements RemoteDatabaseMetaData {
    private RemoteConnectionImpl rconn;
    public RemoteDatabaseMetaDataImpl(RemoteConnectionImpl rconn) throws RemoteException{
        this.rconn = rconn;
        System.out.println("RemoteDatabaseMetaDataImpl is created.");
    }
    public int getDatabaseMajorVersion() throws RemoteException {
        return 2;
    }
    public int getDatabaseMinorVersion() throws RemoteException {
        return 10;
    }
    public RemoteResultSet getTables() throws RemoteException {
        try {
            Transaction tx = rconn.getTransaction();
            Plan pln = SimpleDB.planner().createQueryPlan("select tblname from tblcat", tx);
            return new RemoteResultSetImpl(pln, rconn);
        }
        catch(RuntimeException e) {
            rconn.rollback();
            throw e;
        }
    }

}
