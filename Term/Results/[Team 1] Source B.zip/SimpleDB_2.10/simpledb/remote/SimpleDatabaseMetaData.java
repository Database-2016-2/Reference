package simpledb.remote;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Created by wan on 15. 5. 7.
 */
public class SimpleDatabaseMetaData extends DatabaseMetaDataAdapter {
    private RemoteDatabaseMetaData rdmd;
    public SimpleDatabaseMetaData(RemoteDatabaseMetaData rdmd) {
        this.rdmd = rdmd;
    }
    public ResultSet getTables(String catalog, String schemaPattern, String tableNamePattern, String[] types) throws SQLException {
        try {
            RemoteResultSet rrs = rdmd.getTables();
            return new SimpleResultSet(rrs);
        }
        catch(Exception e) {
            throw new SQLException(e);
        }
    }
}
