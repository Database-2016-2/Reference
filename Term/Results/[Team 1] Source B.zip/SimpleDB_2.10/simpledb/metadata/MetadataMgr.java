package simpledb.metadata;

import simpledb.tx.Transaction;
import simpledb.record.*;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

public class MetadataMgr {
   private static TableMgr  tblmgr;
   private static ViewMgr   viewmgr;
   private static StatMgr   statmgr;
   private static IndexMgr  idxmgr;
   private static SecurityMgr secmgr;
   
   public MetadataMgr(boolean isnew, Transaction tx) {
      tblmgr  = new TableMgr(isnew, tx);
      viewmgr = new ViewMgr(isnew, tblmgr, tx);
      statmgr = new StatMgr(tblmgr, tx);
      idxmgr  = new IndexMgr(isnew, tblmgr, tx);
      secmgr  = new SecurityMgr(isnew, tblmgr, tx);
   }
   
   public void createTable(String tblname, Schema sch, Transaction tx) {
      tblmgr.createTable(tblname, sch, tx);
   }
   
   public TableInfo getTableInfo(String tblname, Transaction tx) {
      return tblmgr.getTableInfo(tblname, tx);
   }
   
   public void createView(String viewname, String viewdef, Transaction tx) {
      viewmgr.createView(viewname, viewdef, tx);
   }
   
   public String getViewDef(String viewname, Transaction tx) {
      return viewmgr.getViewDef(viewname, tx);
   }
   
   public void createIndex(String idxname, String tblname, String fldname, Transaction tx) {
      idxmgr.createIndex(idxname, tblname, fldname, tx);
   }
   
   public Map<String,IndexInfo> getIndexInfo(String tblname, Transaction tx) {
      return idxmgr.getIndexInfo(tblname, tx);
   }
   
   public StatInfo getStatInfo(String tblname, TableInfo ti, Transaction tx) {
      return statmgr.getStatInfo(tblname, ti, tx);
   }
   public boolean checkPriv(String username, String operation, String tblname, Transaction tx) {
      return secmgr.checkPriv(username, operation, tblname, tx);
   }

   public boolean userAuth(String username, String pass, Transaction tx) {
      return secmgr.userAuth(username, pass, tx);
   }

   public Collection<String> getFields(String tblname, Transaction tx) {
      return tblmgr.getFields(tblname, tx);
   }

   // for RemoteDatabaseMetaData
   public ArrayList<String> getTables(Transaction tx) {
      return tblmgr.getTables(tx);
   }

   public boolean createUser(String username, String pass, Transaction tx) {
      return secmgr.createUser(username, pass, tx);
   }

   public boolean isExist(String tblname, Transaction tx) {
      return tblmgr.isExist(tblname, tx);
   }

   public boolean grantUser(String username, String tblname, Collection<String> privs, Transaction tx) { return secmgr.grantUser(username, tblname, privs, tx);}
}
