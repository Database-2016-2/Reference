package simpledb.metadata;

import simpledb.record.RecordFile;
import simpledb.record.Schema;
import simpledb.record.TableInfo;
import simpledb.tx.Transaction;

import java.util.Collection;
import java.util.Iterator;

/**
 * Created by WanH on 2015-05-18.
 */
class SecurityMgr {
    TableMgr tblMgr;
    Schema pcatsch;
    Schema ucatsch;
    private static int MAX_USER = 16;

    public SecurityMgr(boolean isNew, TableMgr tblMgr, Transaction tx) {
        this.tblMgr = tblMgr;

        // priv schema
        this.pcatsch = new Schema();
        pcatsch.addStringField("tblname", TableMgr.MAX_NAME);
        pcatsch.addStringField("username", MAX_USER);
        pcatsch.addIntField("select");
        pcatsch.addIntField("insert");
        pcatsch.addIntField("update");
        pcatsch.addIntField("delete");
        pcatsch.addIntField("grant");

        // username schema
        this.ucatsch = new Schema();
        this.ucatsch.addStringField("username", MAX_USER);
        this.ucatsch.addStringField("pass", MAX_USER);
        if (isNew) {
            // priv table
            tblMgr.createTable("privcat", this.pcatsch, tx);

            // username table
            tblMgr.createTable("usrcat", this.ucatsch, tx);

            TableInfo ui = new TableInfo("usrcat", this.ucatsch);
            // insert one record into the usrcat
            RecordFile ucatfile = new RecordFile(ui, tx);

            // add default username
            ucatfile.insert();
            ucatfile.setString("username", "root");
            ucatfile.setString("pass", "simpledb");

            ucatfile.insert();
            ucatfile.setString("username", "wan");
            ucatfile.setString("pass", "1q2w3e");

            ucatfile.close();
        }
    }
    public boolean checkPriv(String username, String operation, String tblname, Transaction tx) {
        TableInfo ti = new TableInfo("privcat", pcatsch);
        RecordFile pcatfile = new RecordFile(ti, tx);
        int privCount = 0;
        while(pcatfile.next()) {
            privCount++;
            if(pcatfile.getString("username").equals(username) && pcatfile.getString("tblname").equals(tblname)) {
                System.out.println("privCount: " + privCount);
                int tmpOK = pcatfile.getInt(operation);
                pcatfile.close();
                return tmpOK == 1;
            }
        }
        System.out.println("privCount: " + privCount);
        pcatfile.close();
        return false;
    }
    public boolean userAuth(String username, String pass, Transaction tx) {
        TableInfo ti = new TableInfo("usrcat", ucatsch);
        RecordFile ucatfile = new RecordFile(ti, tx);
        while(ucatfile.next()) {
            if(ucatfile.getString("username").equals(username) && ucatfile.getString("pass").equals(pass)) {
                ucatfile.close();
                return true;
            }
        }
        ucatfile.close();
        return false;
    }
    public boolean createUser(String username, String pass, Transaction tx) {
        TableInfo ti = new TableInfo("usrcat", ucatsch);
        RecordFile ucatfile = new RecordFile(ti, tx);
        while(ucatfile.next()) {
            if(ucatfile.getString("username").equals(username)) {
                ucatfile.close();
                return false;
            }
        }
        ucatfile.insert();
        ucatfile.setString("username", username);
        ucatfile.setString("pass", pass);
        ucatfile.close();
        return true;
    }
    public boolean grantUser(String username, String tblname, Collection<String> privs, Transaction tx) {
        TableInfo ti = new TableInfo("privcat", pcatsch);
        RecordFile pcatfile = new RecordFile(ti, tx);
        while(pcatfile.next()) {
            if(pcatfile.getString("username").equals(username) && pcatfile.getString("tblname").equals(tblname)) {
                Iterator<String> it = privs.iterator();
                while(it.hasNext()) {
                    String tmp = it.next();
                    System.out.println("current Priv: " + tmp);
                    pcatfile.setInt(tmp, 1);
                }
                pcatfile.close();
                return true;
            }
        }
        pcatfile.close();

        pcatfile = new RecordFile(ti, tx);
        pcatfile.insert();
        pcatfile.setString("tblname", tblname);
        pcatfile.setString("username", username);
        Iterator<String> it = privs.iterator();
        pcatfile.setInt("select", 0);
        pcatfile.setInt("insert", 0);
        pcatfile.setInt("update", 0);
        pcatfile.setInt("delete", 0);
        pcatfile.setInt("grant", 0);

        while(it.hasNext()) {
            String tmp = it.next();
            System.out.println("current Priv: " + tmp);
            pcatfile.setInt(tmp, 1);
        }
        pcatfile.close();
        return true;
    }
}
