package simpledb.materialize;

import simpledb.query.Constant;
import simpledb.query.Scan;
import simpledb.query.UpdateScan;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Created by ilhyun on 6/1/15.
 */
public class HashGroupByScan implements Scan {
  private Scan s;
  private HashMap<GroupValue,Collection<AggregationFn>> hashtable = new HashMap<GroupValue,Collection<AggregationFn>>();
  private Collection<String> groupfields;
  private Collection<AggregationFn> aggfns;
  private GroupValue groupval;
  private boolean moregroups;
  private Iterator<GroupValue> iter;
 // int modulosize = 3;

  /**
   * Creates a groupby scan, given a grouped table scan.
   * @param s the grouped scan
   * @param groupfields the group fields
   * @param aggfns the aggregation functions
   */
  public HashGroupByScan(Scan s, Collection<String> groupfields, Collection<AggregationFn> aggfns) {
    this.s = s;
    this.groupfields = groupfields;
    this.aggfns = aggfns;

    hashtable.clear();
    pushIntoHashTable();
    iter = hashtable.keySet().iterator();

    beforeFirst();
  }

  private void pushIntoHashTable(){
    boolean returnvalue = false;
    boolean parse = true;
    GroupValue value;
    int index = 0;
    hashtable.clear();

    while (parse) {
      parse = s.next();
      if (parse) {
        value = new GroupValue ( s, groupfields);//s.getVal(fields[0]);
        Collection<AggregationFn> measure = hashtable.get(value);
        if(measure == null){
          measure = new ArrayList<AggregationFn>();
          for(AggregationFn fn : aggfns){
            CountFn newFn = new CountFn(fn.fieldName());
            newFn.processFirst(null);
            measure.add(newFn);
          }
          hashtable.put(value,measure);
        }
        else{
          for(AggregationFn fn : measure){
            fn.processNext(s);
          }
        }
      }
    }
  }


  /**
   * Positions the scan before the first group.
   * Internally, the underlying scan is always
   * positioned at the first record of a group, which
   * means that this method moves to the
   * first underlying record.
   * @see simpledb.query.Scan#beforeFirst()
   */
  public void beforeFirst() {
    s.beforeFirst();
    moregroups = s.next();
    iter = hashtable.keySet().iterator();
  }

  /**
   * Moves to the next group.
   * The key of the group is determined by the
   * group values at the current record.
   * The method repeatedly reads underlying records until
   * it encounters a record having a different key.
   * The aggregation functions are called for each record
   * in the group.
   * The values of the grouping fields for the group are saved.
   * @see simpledb.query.Scan#next()
   */
  public boolean next() {
    if(!iter.hasNext())
      return false;
    groupval = iter.next();
    return true;
  }

  /**
   * Closes the scan by closing the underlying scan.
   * @see simpledb.query.Scan#close()
   */
  public void close() {
    hashtable = null;
    iter = null;
    s.close();
  }

  /**
   * Gets the Constant value of the specified field.
   * If the field is a group field, then its value can
   * be obtained from the saved group value.
   * Otherwise, the value is obtained from the
   * appropriate aggregation function.
   * @see simpledb.query.Scan#getVal(java.lang.String)
   */
  public Constant getVal(String fldname) {
    if (groupfields.contains(fldname))
      return groupval.getVal(fldname);
    for (AggregationFn fn : hashtable.get(groupval))
      if ( ((CountFn)fn).onlyfieldName().equals(fldname))
        return fn.value();
    throw new RuntimeException("field " + fldname + " not found.");
  }

  /**
   * Gets the integer value of the specified field.
   * If the field is a group field, then its value can
   * be obtained from the saved group value.
   * Otherwise, the value is obtained from the
   * appropriate aggregation function.
   * @see simpledb.query.Scan#getVal(java.lang.String)
   */
  public int getInt(String fldname) {
    return (Integer)getVal(fldname).asJavaVal();
  }

  /**
   * Gets the string value of the specified field.
   * If the field is a group field, then its value can
   * be obtained from the saved group value.
   * Otherwise, the value is obtained from the
   * appropriate aggregation function.
   * @see simpledb.query.Scan#getVal(java.lang.String)
   */
  public String getString(String fldname) {
    return (String)getVal(fldname).asJavaVal();
  }

  /** Returns true if the specified field is either a
   * grouping field or created by an aggregation function.
   * @see simpledb.query.Scan#hasField(java.lang.String)
   */
  public boolean hasField(String fldname) {
    if (groupfields.contains(fldname))
      return true;
    for (AggregationFn fn : aggfns)
      if (fn.fieldName().equals(fldname))
        return true;
    return false;
  }

}