package simpledb.materialize;

import simpledb.query.Constant;
import simpledb.query.Plan;
import simpledb.query.Scan;
import simpledb.record.Schema;
import simpledb.tx.Transaction;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

/**
 * Created by ilhyun on 6/1/15.
 */
public class HashGroupByPlan implements Plan {
  private Plan p;
  private Collection<String> groupfields;
  private Collection<AggregationFn> aggfns;
  private Schema sch = new Schema();

 // private int modulosize = 3;

  /**
   * Creates a groupby plan for the underlying query.
   * The grouping is determined by the specified
   * collection of group fields,
   * and the aggregation is computed by the
   * specified collection of aggregation functions.
   * @param p a plan for the underlying query
   * @param groupfields the group fields
   * @param aggfns the aggregation functions
   * @param tx the calling transaction
   */
  public HashGroupByPlan(Plan p, Collection<String> groupfields, Collection<AggregationFn> aggfns, Transaction tx) {
    List<String> grouplist = new ArrayList<String>();
    grouplist.addAll(groupfields);
    this.p = p;
    this.groupfields = groupfields;
    this.aggfns = aggfns;
    for (String fldname : groupfields)
      sch.add(fldname, p.schema());
    for (AggregationFn fn : aggfns)
      sch.addIntField(fn.fieldName());
  }

  /**
   * This method opens a sort plan for the specified plan.
   * The sort plan ensures that the underlying records
   * will be appropriately grouped.
   * @see simpledb.query.Plan#open()
   */
  public Scan open() {

    Scan src = p.open();

    return new HashGroupByScan(src, groupfields, aggfns);
  }

  /**
   * Returns the number of blocks required to
   * compute the aggregation,
   * which is one pass through the sorted table.
   * It does <i>not</i> include the one-time cost
   * of materializing and sorting the records.
   * @see simpledb.query.Plan#blocksAccessed()
   */
  public int blocksAccessed() {
    return p.blocksAccessed();
  }

  /**
   * Returns the number of groups.  Assuming equal distribution,
   * this is the product of the distinct values
   * for each grouping field.
   * @see simpledb.query.Plan#recordsOutput()
   */
  public int recordsOutput() {
    int numgroups = 1;
    for (String fldname : groupfields)
      numgroups *= p.distinctValues(fldname);
    return numgroups;
  }

  /**
   * Returns the number of distinct values for the
   * specified field.  If the field is a grouping field,
   * then the number of distinct values is the same
   * as in the underlying query.
   * If the field is an aggregate field, then we
   * assume that all values are distinct.
   * @see simpledb.query.Plan#distinctValues(java.lang.String)
   */
  public int distinctValues(String fldname) {
    if (p.schema().hasField(fldname))
      return p.distinctValues(fldname);
    else
      return recordsOutput();
  }

  /**
   * Returns the schema of the output table.
   * The schema consists of the group fields,
   * plus one field for each aggregation function.
   * @see simpledb.query.Plan#schema()
   */
  public Schema schema() {
    return sch;
  }
}

